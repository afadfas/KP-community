package com.example.demo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.model.entity.User;
import com.example.demo.model.vo.ArticleVo;
import com.example.demo.model.vo.UserVo;
import com.example.demo.service.UserService;
import com.example.demo.utils.DataTimeUtil;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Resource
    private UserService userService;

    @PostMapping("")
    public void save(@RequestBody User user) throws Exception {
        if (userService.getOne(new QueryWrapper<User>().in("phone", user.getPhone())) != null)
            throw new Exception("当前手机号码已注册");
        if (userService.getOne(new QueryWrapper<User>().in("nickname", user.getNickname())) != null)
            throw new Exception("该昵称已存在");
        user.setCreateAt(DataTimeUtil.getNowTimeString());
        userService.save(user);
    }

    @PostMapping("/login")
    public UserVo login(@RequestBody User user) throws Exception{
        return userService.login(user);
    }

    @PostMapping("/ReName")
    public void ReName(@RequestBody User user) throws Exception{
        userService.Rename(user);
    }

    @PostMapping("/ManageLogin")
    public UserVo ManageLogin(@RequestBody User user) throws Exception{
        return userService.ManageLogin(user);
    }

    @PostMapping("/findAllUser")
    public List<User> findAllUser(String id) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.ne("id",id);
        return userService.list(wrapper);
    }

    @PostMapping("/DeleteUser")
    public void DeleteUser(String id) { userService.DeleteUser(id); }


}
