package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.model.entity.User;
import com.example.demo.model.vo.ArticleVo;
import com.example.demo.model.vo.UserVo;

import java.util.List;

public interface UserService extends IService<User> {

    UserVo login(User user) throws Exception;

    void Rename(User user) throws Exception;

    UserVo ManageLogin(User user) throws  Exception;

    void DeleteUser(String id);

}
