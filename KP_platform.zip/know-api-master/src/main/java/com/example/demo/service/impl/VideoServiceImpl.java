package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.mapper.VideoMapper;
import com.example.demo.model.entity.User;
import com.example.demo.model.entity.Video;
import com.example.demo.service.VideoService;
import com.example.demo.utils.DataTimeUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class VideoServiceImpl implements VideoService {

    @Resource
    private VideoMapper videoMapper;

    @Override
    public void save(Video video) {
        video.setCreateAt(DataTimeUtil.getNowTimeString());
        videoMapper.insert(video);
    }

    @Override
    public List<Video> findAll() {
        return videoMapper.selectList(null);
    }

    public void DeleteVideo(String id){
        QueryWrapper<Video> wrapper = new QueryWrapper<>();
        wrapper.eq("id",id);
        int result = this.videoMapper.deleteById(id);
        System.out.println("result = " + result);
    }

    public List<Video> FindVideoByuid(String uid) {
        Map<String, Object> columnMap = new HashMap<>();
        columnMap.put("uid",uid);
        List<Video> result = this.videoMapper.selectByMap(columnMap);
        return result;
    }


}
