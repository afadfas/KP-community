package com.example.demo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.mapper.VideoMapper;
import com.example.demo.model.entity.User;
import com.example.demo.model.entity.Video;
import com.example.demo.service.VideoService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/api/video")
public class VideoController {

    @Resource
    private VideoService videoService;

    @GetMapping("")
    public List<Video> findAll() {
        return videoService.findAll();
    }

    @PostMapping("")
    public void save(@RequestBody Video video) {
        videoService.save(video);
    }

    @PostMapping("/DeleteVideo")
    public void DeleteVideo(String id) { videoService.DeleteVideo(id); }

    @PostMapping("/FindVideoByuid")
    public List<Video> FindVideoByuid(String uid) { return videoService.FindVideoByuid(uid);
    }

}
