package com.example.demo.constant;

public final class ArticleType {

    public static final String[] list = {"机器学习", "计算机", "工学", "农学", "物理", "高数", "哲学", "其他"};

}
