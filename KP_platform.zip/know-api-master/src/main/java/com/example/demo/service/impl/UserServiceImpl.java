package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.mapper.ArticleMapper;
import com.example.demo.mapper.CommentMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.mapper.VideoMapper;
import com.example.demo.model.entity.Article;
import com.example.demo.model.entity.Comment;
import com.example.demo.model.entity.User;
import com.example.demo.model.entity.Video;
import com.example.demo.model.vo.ArticleVo;
import com.example.demo.model.vo.UserVo;
import com.example.demo.service.UserService;
import com.example.demo.utils.DataTimeUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private ArticleMapper articleMapper;

    @Resource
    private CommentMapper commentMapper;

    @Resource
    private VideoMapper videoMapper;


    @Override
    public UserVo login(User user) throws Exception {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.in("phone", user.getPhone());
        wrapper.in("password", user.getPassword());
        User one = userMapper.selectOne(wrapper);
        if (one == null) throw new Exception("账号密码错误");
        UserVo userVo = new UserVo();
        userVo.setId(one.getId());
        userVo.setNickname(one.getNickname());
        userVo.setAvatar(one.getAvatar());
        userVo.setSchool(one.getSchool());
        userVo.setCreateAt(one.getCreateAt());
        userVo.setArticleCount(articleMapper.selectCount(new QueryWrapper<Article>().in("uid", one.getId())));
        userVo.setVideoCount(videoMapper.selectCount(new QueryWrapper<Video>().in("uid", one.getId())));
        userVo.setCommentCount(commentMapper.selectCount(new QueryWrapper<Comment>().in("uid", one.getId())));
        return userVo;
    }

    public void Rename(User user) throws Exception{
        UpdateWrapper<User> wrapper = new UpdateWrapper<>();
        wrapper.set("nickname", user.getNickname());
        wrapper.set("school", user.getSchool());
        wrapper.set("password", user.getPassword());
        wrapper.eq("id",user.getId());
        int result = this.userMapper.update(user, wrapper);
        System.out.println("result = " + result);
    }

    public UserVo ManageLogin(User user) throws Exception {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.in("phone", user.getPhone());
        wrapper.in("password", user.getPassword());
        wrapper.eq("id","8b6911d2e320ae91cf2306db2185539e");
        User one = userMapper.selectOne(wrapper);
        if (one == null) throw new Exception("账号密码错误");
        UserVo userVoAdmin = new UserVo();
        userVoAdmin.setId(one.getId());
        userVoAdmin.setNickname(one.getNickname());
        userVoAdmin.setAvatar(one.getAvatar());
        userVoAdmin.setSchool(one.getSchool());
        userVoAdmin.setCreateAt(one.getCreateAt());
        userVoAdmin.setArticleCount(articleMapper.selectCount(new QueryWrapper<Article>().in("uid", one.getId())));
        userVoAdmin.setVideoCount(videoMapper.selectCount(new QueryWrapper<Video>().in("uid", one.getId())));
        userVoAdmin.setCommentCount(commentMapper.selectCount(new QueryWrapper<Comment>().in("uid", one.getId())));
        return userVoAdmin;
    }

    public void DeleteUser(String id){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("id",id);
        int result = this.userMapper.deleteById(id);
        System.out.println("result = " + result);

    }

}
